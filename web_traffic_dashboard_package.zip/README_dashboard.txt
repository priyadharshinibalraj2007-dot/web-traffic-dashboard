WEB TRAFFIC ANALYTICS DASHBOARD

Files:
- web_traffic_dashboard.html: interactive dashboard with filters, KPI cards, charts, session table, and CSV export.

To publish a public live URL:
1. Open https://app.netlify.com/drop in a browser.
2. Upload this HTML file (or unzip the accompanying package and upload the folder).
3. Wait for Netlify to deploy the site.
4. Copy the generated public URL and submit that URL in Workora under Public Live Dashboard URL.

Note: This dashboard is built from the supplied web_traffic.pdf session records. The source data does not contain revenue, churn, or ticket-size fields, so those metrics are not fabricated. The dashboard uses web-traffic KPIs instead.
